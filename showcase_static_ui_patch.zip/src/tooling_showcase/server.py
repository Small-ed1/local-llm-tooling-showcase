from __future__ import annotations

from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen
import json
import mimetypes

from tooling_showcase.service import ShowcaseService


STATIC_DIR = Path(__file__).with_name("static")


def run_server(service: ShowcaseService, host: str, port: int) -> int:
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            clean_path = urlparse(self.path).path

            if clean_path in {"/api/journal", "/api/adapters", "/api/tools", "/api/models"}:
                self._handle_api_get(clean_path)
                return

            if clean_path in {"/", "/index.html"}:
                self._send_static_file(STATIC_DIR / "index.html")
                return

            if clean_path.startswith("/static/"):
                relative = clean_path.removeprefix("/static/")
                self._send_static_file(STATIC_DIR / relative)
                return

            self.send_error(HTTPStatus.NOT_FOUND)

        def do_POST(self) -> None:  # noqa: N802
            clean_path = urlparse(self.path).path

            if clean_path == "/api/ask":
                payload = self._read_json_body()
                text = str(payload.get("text", "")).strip()
                confirm = bool(payload.get("confirm", False))
                model = str(payload.get("model", "")).strip() or None
                system_prompt = str(payload.get("system_prompt", "")).strip() or None
                stream = bool(payload.get("stream", False))
                result = service.handle(
                    text,
                    confirm=confirm,
                    model=model,
                    system_prompt=system_prompt,
                    stream=stream,
                )
                if stream:
                    self._send_stream(
                        _stream_server_chunks(
                            result.ok, result.message, result.tool_calls
                        )
                    )
                    return
                self._send_json(
                    {
                        "ok": result.ok,
                        "message": result.message,
                        "tool_calls": [call.__dict__ for call in result.tool_calls],
                    },
                    status=HTTPStatus.OK if result.ok else HTTPStatus.BAD_GATEWAY,
                )
                return

            if clean_path == "/api/run":
                payload = self._read_json_body()
                goal = str(payload.get("goal", "")).strip()
                max_steps = int(payload.get("max_steps", 5))
                confirm = bool(payload.get("confirm", False))
                result = service.run_autonomous(
                    goal, max_steps=max_steps, confirm=confirm
                )
                if bool(payload.get("stream", False)):
                    self._send_stream(
                        _stream_server_chunks(
                            result.ok, result.message, result.tool_calls
                        )
                    )
                    return
                self._send_json(
                    {
                        "ok": result.ok,
                        "message": result.message,
                        "tool_calls": [call.__dict__ for call in result.tool_calls],
                    },
                    status=HTTPStatus.OK if result.ok else HTTPStatus.BAD_GATEWAY,
                )
                return

            self.send_error(HTTPStatus.NOT_FOUND)

        def _handle_api_get(self, clean_path: str) -> None:
            if clean_path == "/api/journal":
                self._send_json({"events": service.recent_events(limit=20)})
                return
            if clean_path == "/api/adapters":
                self._send_json({"adapters": service.adapter_cards()})
                return
            if clean_path == "/api/tools":
                self._send_json({"tools": service.tools.available_tools()})
                return
            if clean_path == "/api/models":
                self._send_json(_load_ollama_models(service))
                return
            self.send_error(HTTPStatus.NOT_FOUND)

        def log_message(self, format: str, *args) -> None:  # noqa: A003
            return

        def _read_json_body(self) -> dict:
            length = int(self.headers.get("Content-Length", "0"))
            try:
                payload = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError:
                return {}
            return payload if isinstance(payload, dict) else {}

        def _send_static_file(self, path: Path) -> None:
            try:
                resolved = path.resolve()
                static_root = STATIC_DIR.resolve()
                if static_root not in resolved.parents and resolved != static_root:
                    self.send_error(HTTPStatus.FORBIDDEN)
                    return
                data = resolved.read_bytes()
            except FileNotFoundError:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            except OSError as exc:
                self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))
                return

            content_type = mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _send_json(self, payload: dict, *, status: HTTPStatus = HTTPStatus.OK) -> None:
            data = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _send_stream(self, payloads: list[dict]) -> None:
            data = "".join(json.dumps(payload) + "\n" for payload in payloads).encode(
                "utf-8"
            )
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = ThreadingHTTPServer((host, port), Handler)
    print(f"Showcase UI available at http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


def _load_ollama_models(service: ShowcaseService) -> dict:
    tags_url = _ollama_tags_url(service.config.ollama.endpoint)
    request = Request(tags_url, method="GET")
    try:
        with urlopen(request, timeout=10) as response:
            raw = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        return {"ok": False, "models": [], "error": f"Ollama HTTP {exc.code}: {body}"}
    except URLError as exc:
        return {"ok": False, "models": [], "error": f"Failed to reach Ollama: {exc}"}
    except json.JSONDecodeError as exc:
        return {"ok": False, "models": [], "error": f"Invalid Ollama model JSON: {exc}"}

    models = []
    for item in raw.get("models", []):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        if not name:
            continue
        models.append(
            {
                "name": name,
                "modified_at": item.get("modified_at"),
                "size": item.get("size"),
                "details": item.get("details") or {},
            }
        )
    models.sort(key=lambda item: item["name"].lower())
    return {"ok": True, "models": models, "endpoint": tags_url}


def _ollama_tags_url(endpoint: str) -> str:
    parsed = urlparse(endpoint)
    if not parsed.scheme or not parsed.netloc:
        return "http://127.0.0.1:11434/api/tags"
    return f"{parsed.scheme}://{parsed.netloc}/api/tags"


def _stream_server_chunks(ok: bool, message: str, tool_calls: list) -> list[dict]:
    chunks = [
        {"type": "chunk", "delta": chunk, "done": False}
        for chunk in _chunk_text(message)
    ]
    chunks.append(
        {
            "type": "final",
            "ok": ok,
            "message": message,
            "tool_calls": [call.__dict__ for call in tool_calls],
            "done": True,
        }
    )
    return chunks


def _chunk_text(text: str, max_chunk_size: int = 120) -> list[str]:
    if not text:
        return [""]
    words = text.split()
    chunks: list[str] = []
    current = ""
    for word in words:
        candidate = word if not current else current + " " + word
        if len(candidate) > max_chunk_size and current:
            chunks.append(current)
            current = word
        else:
            current = candidate
    if current:
        chunks.append(current)
    return chunks or [text]
