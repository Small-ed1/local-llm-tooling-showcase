const modelEl = document.getElementById("model");
const systemPromptEl = document.getElementById("system-prompt");
const confirmEl = document.getElementById("confirm");
const messagesEl = document.getElementById("messages");
const formEl = document.getElementById("chat-form");
const promptEl = document.getElementById("prompt");
const sendEl = document.getElementById("send");
const clearEl = document.getElementById("clear");
const refreshModelsEl = document.getElementById("refresh-models");
const statusEl = document.getElementById("status");

let messages = [];
let isRunning = false;

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function setStatus(text, isError = false) {
  statusEl.textContent = text;
  statusEl.classList.toggle("error", isError);
}

function setRunning(running) {
  isRunning = running;
  sendEl.disabled = running;
  refreshModelsEl.disabled = running;
}

function renderMessages() {
  if (!messages.length) {
    messagesEl.innerHTML = `<div class="empty">Pick a model, type a message, and send it. Tiny interface, actual teeth.</div>`;
    return;
  }

  messagesEl.innerHTML = messages.map((message) => `
    <article class="message ${escapeHtml(message.role)}">
      <div class="meta">${escapeHtml(message.role)}</div>
      ${escapeHtml(message.content)}
    </article>
  `).join("");
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function loadModels() {
  setStatus("Loading models...");
  try {
    const res = await fetch("/api/models");
    const data = await res.json();
    if (!res.ok || !data.ok) {
      throw new Error(data.error || `HTTP ${res.status}`);
    }

    const previous = modelEl.value;
    modelEl.innerHTML = "";

    for (const model of data.models || []) {
      const option = document.createElement("option");
      option.value = model.name;
      option.textContent = model.name;
      modelEl.appendChild(option);
    }

    if (previous && [...modelEl.options].some((option) => option.value === previous)) {
      modelEl.value = previous;
    }

    if (!modelEl.options.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No models found";
      modelEl.appendChild(option);
      setStatus("Connected to Ollama, but no models were found.", true);
      return;
    }

    setStatus(`Loaded ${modelEl.options.length} model${modelEl.options.length === 1 ? "" : "s"}.`);
  } catch (error) {
    modelEl.innerHTML = `<option value="">Models unavailable</option>`;
    setStatus(`Model load failed: ${error.message}`, true);
  }
}

async function sendMessage(text) {
  if (isRunning) return;
  const model = modelEl.value;
  if (!model) {
    setStatus("Pick a model first.", true);
    return;
  }

  messages.push({ role: "user", content: text });
  const assistant = { role: "assistant", content: "" };
  messages.push(assistant);
  renderMessages();

  setRunning(true);
  setStatus("Sending...");

  try {
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        model,
        system_prompt: systemPromptEl.value.trim(),
        confirm: confirmEl.checked,
        stream: true,
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status}${body ? `: ${body.slice(0, 180)}` : ""}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let finalPayload = null;

    setStatus("Streaming...");

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (!line.trim()) continue;
        const packet = JSON.parse(line);
        if (packet.type === "chunk") {
          assistant.content += (assistant.content ? " " : "") + (packet.delta || "");
          renderMessages();
        }
        if (packet.type === "final") {
          finalPayload = packet;
        }
      }
    }

    if (finalPayload) {
      assistant.content = finalPayload.message || assistant.content;
      renderMessages();
      setStatus(finalPayload.ok ? "Done." : "Request failed.", !finalPayload.ok);
    } else {
      setStatus("Done.");
    }
  } catch (error) {
    assistant.content = `Request failed: ${error.message}`;
    renderMessages();
    setStatus(`Failed: ${error.message}`, true);
  } finally {
    setRunning(false);
  }
}

formEl.addEventListener("submit", (event) => {
  event.preventDefault();
  const text = promptEl.value.trim();
  if (!text) return;
  promptEl.value = "";
  sendMessage(text);
});

promptEl.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
    formEl.requestSubmit();
  }
});

clearEl.addEventListener("click", () => {
  messages = [];
  renderMessages();
  setStatus("Cleared.");
});

refreshModelsEl.addEventListener("click", loadModels);

renderMessages();
loadModels();
